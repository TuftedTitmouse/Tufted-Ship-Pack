package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class HeavyOrdinanceExpansion extends BaseHullMod {

	public static final float AMMO_BONUS = 200f;
	public static final float PENALTY = 0.2f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getMissileAmmoBonus().modifyPercent(id, AMMO_BONUS);
		stats.getCargoMod().modifyMult(id, PENALTY);
		stats.getFuelMod().modifyMult(id, PENALTY);
		//stats.getMissileWeaponDamageMult().modifyPercent(id, 1000f);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) AMMO_BONUS;
		if (index == 1) return "" + (int) ((1f - PENALTY )* 100) + "%";
		return null;
	}


}
